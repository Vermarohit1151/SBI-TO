import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import bank.SavingsAccount;
// TDD Test Driven Development
public class SavingsAccountTesting {
	EntityManagerFactory eMF = Persistence.createEntityManagerFactory("MyJPA");
	//System.out.println("Got the Entity Manager Factory "+eMF);
	
	EntityManager eM = eMF.createEntityManager();
	//System.out.println("Got the Entity Manager "+eM);
	@Test
	public void creationOfSavingsAccountTest() {
		
		System.out.println("Begin testing...");
		
		
		SavingsAccount saObj = new SavingsAccount();
		System.out.println("Empty object is created");
		
		saObj.setAccNumber(420);
		saObj.setAccBalance(300000);
		saObj.setAccHolder("Deependra");
		System.out.println("Object is filled up");
		
		EntityTransaction trans = eM.getTransaction();
		System.out.println("Got the Entity Txn "+trans);
		
		trans.begin();
		eM.persist(saObj);
		System.out.println();
		trans.commit();
		System.out.println("Savings account object persisted");
		
		
		
		eM.close();
		System.out.println("Entity Manager closed");
		System.out.println("End testing...");
		
	}
	
	@Test
	public void findSavingsAccount() {
		Assertions.assertTrue(eMF!=null);
		Assertions.assertTrue(eM!=null);
		SavingsAccount sa = eM.find(SavingsAccount.class, 220);
		Assertions.assertTrue(sa!=null);
		
		System.out.println("Object Found");
		
		System.out.println("ACC_NO\t:"+sa.getAccNumber());
		System.out.println("ACC_NAME\t:"+sa.getAccHolder());
		System.out.println("ACC_BAL\t:"+sa.getAccBalance());
	}
	
	@Test
	public void modifySavingsAccount() {
		Assertions.assertTrue(eMF!=null);
		Assertions.assertTrue(eM!=null);
		
		EntityTransaction trans = eM.getTransaction();
		System.out.println("Got the Entity Txn "+trans);
		
		trans.begin();
		
		SavingsAccount sa = eM.find(SavingsAccount.class, 220);
		Assertions.assertTrue(sa!=null);
		
		System.out.println("Object Found");
		
		
		System.out.println("ACC_NO\t:"+sa.getAccNumber());
		System.out.println("ACC_NAME\t:"+sa.getAccHolder());
		System.out.println("ACC_BAL\t:"+sa.getAccBalance());
		
	
		System.out.println("Merging account");
		
		sa.setAccBalance(150000);
		sa.setAccHolder("Aarvi");
	//	sa.setAccNumber(122);
		eM.merge(sa);
		trans.commit();
		System.out.println("Modification done");
		eM.close();
		System.out.println("Entity Manager closed");
		System.out.println("End testing...");
	}
	
	
	@Test
	public void deleteSavingsAccount() {
		Assertions.assertTrue(eMF!=null);
		Assertions.assertTrue(eM!=null);
		
		EntityTransaction trans = eM.getTransaction();
		System.out.println("Got the Entity Txn "+trans);
		
		trans.begin();
		
		SavingsAccount sa = eM.find(SavingsAccount.class, 420);
		Assertions.assertTrue(sa!=null);
		
		System.out.println("Object Found");
		System.out.println("Deleting account "+sa.getAccNumber());
		
		System.out.println("ACC_NO\t:"+sa.getAccNumber());
		System.out.println("ACC_NAME\t:"+sa.getAccHolder());
		System.out.println("ACC_BAL\t:"+sa.getAccBalance());
		
	
		System.out.println("Deleting Account....");
		
		eM.remove(sa);
		trans.commit();
		System.out.println("Deleted....");
		
	}
	
	@Test
	 public void findAllSavingsAccount() {
		 	Assertions.assertTrue(eMF!=null);
			Assertions.assertTrue(eM!=null);
			
			
			Query query = eM.createQuery("from SavingsAccount");
			
			List<SavingsAccount> savObjList = query.getResultList();
			
			Assertions.assertTrue(savObjList.size()>0);
				
			for(SavingsAccount sa: savObjList) {
				System.out.println("ACC_NO\t:"+sa.getAccNumber());
				System.out.println("ACC_NAME\t:"+sa.getAccHolder());
				System.out.println("ACC_BALANCE\t:"+sa.getAccBalance());
				System.out.println("------------------------");
			}
			
	 }
}
