package bank;

public class SAORMTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SavingsAccountDAOImpl savObj = new SavingsAccountDAOImpl();
		savObj.deleteSavingsAccount(2000);;
		
		savObj.closeResources();
		
//		sa.setAccBalance(56565);
//		sa.setAccHolder("Rv");
//		sa.setAccNumber(2000);
//		try {
//			savObj.createSavingsAccount(sa);
//		}
//		catch (Exception e) {
//			// TODO: handle exception
//		}
		
		
	}

}
