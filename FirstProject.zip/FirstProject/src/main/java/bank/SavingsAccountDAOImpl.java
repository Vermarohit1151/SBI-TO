package bank;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;





public class SavingsAccountDAOImpl implements SavingsAccountDAO {
	EntityManagerFactory eMF;
	EntityManager eM;
	
		public SavingsAccountDAOImpl() {
			 eMF = Persistence.createEntityManagerFactory("MyJPA");

			 eM = eMF.createEntityManager();
			
		}

		@Override
		public void createSavingsAccount(SavingsAccount savObj) {
			// TODO Auto-generated method stub

			eM.getTransaction().begin();
		
			eM.persist(savObj);
			
			eM.getTransaction().commit();

		}

		@Override
		public SavingsAccount findSavingsAccount(int accountNumber) {
			
			SavingsAccount sa = eM.find(SavingsAccount.class, accountNumber);
			
			if(sa!=null) {
			return sa;
			}
			else {
				return null;
			}
		}

		@Override
		public List<SavingsAccount> findAllSavingsAccount() {
			Query query = eM.createQuery("from SavingsAccount");
			List<SavingsAccount> savObjList = query.getResultList();
			
			
			return savObjList;
		}

		@Override
		public void modifySavingsAccount(SavingsAccount savObj) {
			eM.getTransaction().begin();
			eM.merge(savObj);
		eM.getTransaction().commit();
			
		}

		@Override
		public void deleteSavingsAccount(int accountNumber) {
			eM.getTransaction().begin();
			SavingsAccount savAcc = eM.find(SavingsAccount.class, accountNumber);
			eM.remove(savAcc);
		eM.getTransaction().commit();
			
		}
		public void closeResources() {
			eM.close();
			
		}
}
