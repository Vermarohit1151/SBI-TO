package bank;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class OrmTest {
	public static void main(String[] args) {
		
		//following line will read META-INF/persistence.xml
		// and its settings
		EntityManagerFactory eMF = Persistence.createEntityManagerFactory("MyJPA");
		System.out.println("Got the Entity Manager Factory "+eMF);
		
		EntityManager eM = eMF.createEntityManager();
		System.out.println("Got the Entity Manager "+eM);
		
		SavingsAccount saObj = new SavingsAccount();
		System.out.println("Empty object is created");
		
		saObj.setAccNumber(420);
		saObj.setAccBalance(300000);
		saObj.setAccHolder("Deependra");
		System.out.println("Object is filled up");
		
		EntityTransaction trans = eM.getTransaction();
		System.out.println("Got the Entity Txn "+trans);
		
		trans.begin();
		eM.persist(saObj);
		System.out.println();
		trans.commit();
		System.out.println("Savings account object persisted");
		
		
		
		eM.close();
		System.out.println("Entity Manager closed");
	}
}
