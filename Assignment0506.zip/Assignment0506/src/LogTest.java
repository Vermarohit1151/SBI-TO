import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Iterator;

public class LogTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ArrayList<Log> systemLog = new ArrayList<Log>();
		
		Log s01 = new Log("LLMS user creation error", "database error", 3);
		Log s02 = new Log("Sanction not granted", "A & L criteria not met", 1);
		Log s03 = new Log("Cannot create new lead, CIBIL error", "CIBIL fetch error", 4);
		systemLog.add(s01);
		systemLog.add(s02);
		systemLog.add(s03);
		
		Iterator<Log> logPrinter = systemLog.iterator();
		int i =1;
		while(logPrinter.hasNext()) {
			Log logs = logPrinter.next();
			
			System.out.println("Log L00"+(i++) +"->\n"+logs);
		}
	}

}

class Log{
	String logMsg; 			// Error Description
	String logType;			// Error category
	LocalDateTime logDateTime;	//Current time and date
	int logLevel;			// Rating on 1-5 with 5 being Severe
	
	public Log(String logMsg, String logType, int logLevel) {
		super();
		this.logMsg = logMsg;
		this.logType = logType;
		this.logDateTime = LocalDateTime.now();
		this.logLevel = logLevel;
	}

	@Override
	public String toString() {
		return "Log Message = 	" + logMsg + "\nlog Type = 	" + logType + "\nSystemTime = 	" + logDateTime + "\nSeverity Level = 	"
				+ logLevel + "\n--------------------------------";
	}
	
	
	
}