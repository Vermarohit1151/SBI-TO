import java.util.Iterator;
import java.util.TreeSet;

public class PeriodicTableTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TreeSet<ChemicalElement> periodicTable = new TreeSet<ChemicalElement>();
		
		periodicTable.add(new ChemicalElement(1, 1.008f, "H", "Hydrogen")) ;
		periodicTable.add(new ChemicalElement(2, 4.002f, "He", "Helium")) ;
		periodicTable.add(new ChemicalElement(79, 196.995f, "Au", "Gold")) ;
		periodicTable.add(new ChemicalElement(47, 107.868f, "Ag", "Silver")) ;
		
		
		Iterator<ChemicalElement> chemistry = periodicTable.iterator();
		
		while(chemistry.hasNext()) {
			ChemicalElement table = chemistry.next();
			System.out.println("\n"+table);
		}
	}

}

class ChemicalElement implements Comparable<ChemicalElement>{
	int atomicNumber;
	float atomicWeight;
	String atomicFormula, atomicName;
	public ChemicalElement(int atomicNumber, float atomicWeight, String atomicFormula, String atomicName) {
		super();
		this.atomicNumber = atomicNumber;
		this.atomicWeight = atomicWeight;
		this.atomicFormula = atomicFormula;
		this.atomicName = atomicName;
	}
	@Override
	public String toString() {
		return "Atomic Number=\t" + atomicNumber + "\nAtomic Name=\t" + atomicName +"\nAtomic Weight=\t" + atomicWeight + "amu\nAtomic Formula=\t"
				+ atomicFormula +  "\n----------------------";
	}
	
	@Override
	public int compareTo(ChemicalElement c2) {
		// TODO Auto-generated method stub
		if(this.atomicNumber > c2.atomicNumber) {
			 return 1;
		}
		else if(this.atomicNumber < c2.atomicNumber) {
			return -1;
		}
		else
			return 0;
		
	}
	
	
	
}