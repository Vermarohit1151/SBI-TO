import java.util.Iterator;
import java.util.LinkedList;

public class ContactTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedList<Contact> contacts = new LinkedList<Contact>();
		
		Contact C1 = new Contact("Rohit Verma", 7506563687l, "Rohitverma13@sbi.co.in", "Vermarohit11");
		Contact C2 = new Contact("Gaurav Kaushik", 90655287450l, "GauravKaushik2@sbi.co.in", "KGaurav2");
		//System.out.println("Hello");
		contacts.add(C1);
		contacts.add(C2);
		
		Iterator<Contact> contactIter = contacts.iterator();
		int i =1;
		while(contactIter.hasNext()) {
			Contact logs = contactIter.next();
			
			System.out.println("Contact "+(i++) +"->\n"+logs);
		}
	}

}

class Contact{
	String contactName;
	long mobileNumber;
	String emailID;
	String linkedInID;
	
	public Contact(String contactName, long mobileNumber, String emailID, String linkedInID) {
		super();
		this.contactName = contactName;
		this.mobileNumber = mobileNumber;
		this.emailID = emailID;
		this.linkedInID = linkedInID;
	}

	@Override
	public String toString() {
		return "ContactName		:"+contactName+"\nMobileNumber		:" + mobileNumber + "\nEmail ID		:" + emailID
				+ "\nLinkedInID		:" + linkedInID + "\n-----------------------------------";
	}
	
	
}