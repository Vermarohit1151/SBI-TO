import java.util.HashSet;
import java.util.Iterator;

public class BookKeeperTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 HashSet<Book> book = new HashSet<Book>();
		 
		 Book b1 = new Book(817992162, "The Monk Who Sold His Ferrari", "Robin Sharma", 335.25f, 198, 2);
		 Book b2 = new Book(817599295, "Time Machine", "H. G. Wells", 129, 144, 1);
		 Book b3 = new Book(051565362,"Harry Potter and The Cursed Child","J. K. Rowling", 1800.75f,336, 1);
		 
		 book.add(b1); 
		 book.add(b2);
		 book.add(b3);
		 
		 Iterator<Book> bookIter = book.iterator();
		 int i = 1;
		 while(bookIter.hasNext()) {
			 Book bookLog = bookIter.next();
			 System.out.println("Book "+ i++ +"\n"+bookLog);
		 }
	}	
}

class Book{
	int bookId;
	String bookTitle,bookAuthor;
	float bookPrice;
	int numberOfPages,bookEdition;
	public Book(int bookId, String bookTitle, String bookAuthor, float bookPrice, int numberOfPages, int bookEdition) {
		super();
		this.bookId = bookId;
		this.bookTitle = bookTitle;
		this.bookAuthor = bookAuthor;
		this.bookPrice = bookPrice;
		this.numberOfPages = numberOfPages;
		this.bookEdition = bookEdition;
	}
	@Override
	public String toString() {
		return "Book Id:	" + bookId + "\nBook Title:	" + bookTitle + "\nBook Author:	" + bookAuthor + "\nBook Price:	Rs."
				+ bookPrice + "\nNumber Of Pages:  " + numberOfPages + "Pages\nBook Edition:	" + bookEdition + "\n----------------------";
	}
	
	
}
