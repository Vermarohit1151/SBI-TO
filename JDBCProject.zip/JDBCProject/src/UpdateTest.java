import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class UpdateTest {
	public static void main(String[] args) {
		
		try {
			//1. load the driver...
			System.out.println("Trying to load the driver...");
			DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
			System.out.println("Loaded the driver.....");
			
			System.out.println("Trying to connect to the DB...");
			Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system", "sysgitc");
			System.out.println("DB connected "+conn);
			PreparedStatement pst = conn.prepareStatement("Update Emp set Sal = ? and job = ? where empno = ? ");
			Scanner sc = new Scanner(System.in);
		
			System.out.println("Enter employee number for which details needs to be changed?");
			int empNumber = sc.nextInt();
			
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery("Select empname from emp where empno ="+empNumber);
			
			if(rs.getRow()!=0) {
				System.out.println("Enter new employee designation");
				String empJob = sc.next();
				
				System.out.println("Enter updated employee salary");
				int salary = sc.nextInt();
				
				pst.setInt(1, empNumber);
			
				pst.setString(2, empJob);
		
				pst.setInt(3, salary);

				
				int rowsInserted = pst.executeUpdate();
				
				System.out.println("Statement executed : rows created : "+rowsInserted);
			}
			
			else {
				EmployeeNotFoundException e = new EmployeeNotFoundException("Employee not found with given Employee ID");
				throw e;
			}
			
			pst.close();  conn.close();
	}
	catch (Exception e) {
		e.printStackTrace();
	}
}}