
public class EmployeeExistsException extends RuntimeException {
	public  EmployeeExistsException(String e) {
		super("Employee Already Exists in Database");
	}
}
