
public class EmployeeNotFoundException extends RuntimeException{
	
	public EmployeeNotFoundException(String a) {
		super("Employee not found in the database");
	}

	
	
}