package myexceptions;

public class EmployeeAlreadyExistsException extends RuntimeException {
	public EmployeeAlreadyExistsException(String msg) {
		super(msg);
	}
}
