
public class PolymorphismTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Doctor d = new Doctor();
		Surgeon s=new Surgeon();
		HeartSurgeon hs = new HeartSurgeon();
		System.out.println("begin of main.........");
		
		Doctor x= new Doctor();
		x.diagnose();
		
		x=new Surgeon();
		x.diagnose(); //late binding
		
		x=new HeartSurgeon();
		x.diagnose(); //late binding
		System.out.println("-------------------------");
		
		d.diagnose(); //d.Doctor::diagnose()
//		d.surgery(); //throws error
//		d.heartSurgery(); //throws error
		System.out.println("-------------------------");
		
		s.diagnose(); //s.Doctor.diagnose() - inherited
		s.surgery();  //s.Surgeon.surgery() - exclusive
		//s.heartSurgery(); //throws error
		System.out.println("--------------------------");
		
		hs.diagnose(); //hs.Doctor.diagnose() - inherited
		hs.surgery(); //hs.Surgeon.surgery() - inherited
		hs.heartSurgery(); //hs.HeartSurgeon.heartSurgery() - exclusive
		System.out.println("-------------------------");
		System.out.println("end of main.........");
	}

}

class Doctor
{
	void diagnose()
	{
		System.out.println("diagnose method from Doctor class...");
	}
}

class Surgeon extends Doctor
{
	void surgery()
	{
		System.out.println("surgery method from surgeon class...");
	}
	
	void diagnose()
	{
		System.out.println("diagnose method from Surgeon class...");
	}
}

class HeartSurgeon extends Surgeon
{
	void heartSurgery()
	{
		System.out.println("heartSurgery method from HeartSurgeon class...");
	}
	
	void diagnose()
	{
		System.out.println("diagnose method from HeartSurgeon class...");
	}
}