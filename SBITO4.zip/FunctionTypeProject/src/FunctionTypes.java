
public class FunctionTypes {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Begin with main");
		
//		InterestCalculator intcalc1 = new InterestCalculator();
//		intcalc1.calcSimpleInterest();
//		System.out.println("-----------------------------------");
//		SavingsAccount saObj1 = new SavingsAccount();
//		saObj1.deposit();
//		saObj1.withdraw();
//		saObj1.withdrawing(5000);
//		saObj1.transfer();
//		System.out.println("-----------------------------------");
//		Kitchen kitchenObj1 = new Kitchen();
//		kitchenObj1.chopping();
//		kitchenObj1.prepareFood();
//		kitchenObj1.serveFood();
//		System.out.println("-----------------------------------");
//		SignalCrossing signalObj1 = new SignalCrossing();
//		signalObj1.red();
//		signalObj1.orange();
//		signalObj1.green();
		
		Area a1 = new Area();
		a1.calAreaOfRectangle();
		a1.calAreaOfRectangle(30, 40);
		int val1 = a1.calcAreaOfRect();
		System.out.println("Area of rectangle from func4:"+val1);
		int val2 = a1.calAreaOfRect(50, 60);
		System.out.println("Area of rectangle form func3:"+val2);
		
	}

}

class InterestCalculator
{
	void calcSimpleInterest()
	{
		System.out.println("Calculating simple inetrest");
	}
}

class SavingsAccount
{
	void withdraw()
	{
		System.out.println("withdrawing funds...");
	}
	
	void withdrawing(int amt)
	{
		System.out.println("withrawing "+amt+"rupees");
	}
	
	
	void deposit()
	{
		System.out.println("Depositing funds...");
	}
	void transfer()
	{
		System.out.println("Trasnfering funds...");
	}
}

class Kitchen
{
	void prepareFood()
	{
		System.out.println("Food is getting prepared");
	}
	
	void serveFood()
	{
		System.out.println("serving the food");
	}
	void chopping()
	{
		System.out.println("chopping the vegetables & meat");
	}
}

class SignalCrossing
{
	void green()
	{
		System.out.println("Go ahead....");
	}
	
	void orange()
	{
		System.out.println("Ready to go....");
	}
	
	void red()
	{
		System.out.println("Please stop.........");
	}
}

class Area
{
	void calAreaOfRectangle()
	{
		int l=20; int b=30;
		int a = l*b;
		System.out.println("Area of rectangle from func1:"+a);
	}
	
	void calAreaOfRectangle(int l, int b)
	{
		int a = l*b;
		System.out.println("Area of rectangle from func2:"+a);
	}
	
	int calAreaOfRect(int l, int b)
	{
		
		return l*b;
		
	}
	
	int calcAreaOfRect()
	{
		int l=20; int b=30;
		return l*b;
	}
}