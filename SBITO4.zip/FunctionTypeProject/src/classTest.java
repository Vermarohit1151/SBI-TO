import java.awt.Frame;

public class classTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Frame f1=new Frame();
		f1.setSize(200,200);
		f1.setTitle("JavaProgramming");
		f1.setLocation(250,250);
		f1.setVisible(true);
		
		Student sObj1 = new Student();
		Student sObj2 = new Student();
		Student sObj3 = new Student();
		Student sObj4 = new Student();
		
		sObj1.setStudDetails(101, "Anil", 5);
		sObj2.setStudDetails(102, "Sunil", 7);
		sObj3.setStudDetails(103, "Ramesh", 4);
		sObj4.setStudDetails(104, "Nilesh", 12);
		
		sObj1.reading();
		sObj2.writeExam();
		sObj3.writeExam();
		sObj4.reading();
		
		Programmer p1 = new Programmer("E111", "sushant", "deloitte", 45689.45);
		Programmer p2 = new Programmer("E222", "rajesh", "infosys", 24549.65);
		Programmer p3 = new Programmer("E333", "neellima", "TCS", 58756.42);
		Programmer p4 = new Programmer("E444", "pradeep", "emphasis", 15689.45);
		Programmer p5 = new Programmer();
		
//		p1.getDetails("E111", "sushant", "deloitte", 45689.45);
//		p2.getDetails("E222", "rajesh", "infosys", 24549.65);
//		p3.getDetails("E333", "neellima", "TCS", 58756.42);
//		p4.getDetails("E444", "pradeep", "emphasis", 15689.45);
		p5.getProgrammer("E555", "Sumitha", "Capgemini", 58745.12);
		
		p1.coder();
		p2.tester();
		p3.ethicalHacker();
		p4.coder();
		
	}

}

class Student
{
	int studRollNo;
	String studName;
	int studClass;
	
	public void setStudDetails(int x, String y, int z)
	{
		studRollNo=x;
		studName=y;
		studClass=z;
	}
	
	public void reading()
	{
		System.out.println("The below student started reading...");
		System.out.println("Roll No: "+studRollNo);
		System.out.println("Name: "+studName);
		System.out.println("Class: "+studClass);
		System.out.println("*************************************");
	}
	
	public void writeExam()
	{
		System.out.println("The below student started writing the exam...");
		System.out.println("Roll No: "+studRollNo);
		System.out.println("Name: "+studName);
		System.out.println("Class: "+studClass);
		System.out.println("*****************************************");
	}
}

class Programmer
{
	String pNo;
	String pName;
	String pCompany;
	double pSal;
	
	Programmer()
	{
		System.out.println("Entering no arg explicit cons....");
		System.out.println("----------------------------------------------");
	}
	
	public void getProgrammer(String pNo, String pName, String pCompany, double pSal)
	{
		
		this.pNo=pNo;
		this.pName=pName;
		this.pCompany=pCompany;
		this.pSal=pSal;
	}
	
	public Programmer(String pNo, String pName, String pCompany, double pSal)
	{
		System.out.println("entered parameterised cons.....");
		this.pNo=pNo;
		this.pName=pName;
		this.pCompany=pCompany;
		this.pSal=pSal;
	}
	public void coder()
	{
		System.out.println("Coding is done by Employee "+pName+" with id "+pNo+" from " +pCompany+" company");
		System.out.println("Annual package is Rs. "+ 12*pSal);
		System.out.println("----------------------------------------------");
	}
	
	public void tester()
	{
		System.out.println("Testing is done by Employee "+pName+" with id "+pNo+" from " +pCompany+" company");
		System.out.println("Annual package is Rs. "+ 12*pSal);
		System.out.println("----------------------------------------------");
	}
	
	public void ethicalHacker()
	{
		System.out.println("Ethical Hacking is done by Employee "+pName+" with id "+pNo+" from " +pCompany+" company");
		System.out.println("Annual package is Rs. "+ 12*pSal);
		System.out.println("----------------------------------------------");
	}
}