import java.time.LocalDate;

public class BankTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("Begin of main.......");

		BankAccount baObj1 = new BankAccount();
		BankAccount baObj2 = new BankAccount();
		BankAccount baObj3 = new BankAccount();
		
		baObj1.setBankAcc(101, "sri", 4587.89,2013,01,29,"1987-06-12");
		baObj2.setBankAcc(102, "rushi", 8457.90,2014,07,07,"1984-12-06");
		baObj3.setBankAcc(103, "nidhi", 54587.87,2019,03,21,"2014-07-07");
		
		baObj1.printAccount();
		baObj2.printAccount();
		baObj3.printAccount();
		
		baObj2.deposit(8733.25);
		baObj2.printAccount();
		
		baObj3.withdrawl(150000);
		baObj3.printAccount();
		
		System.out.println("End of main.......");
	}
	
}

class BankAccount
{
	int accNo;
	String accName;
	double accBalance;
	LocalDate accOpenedDate;
	LocalDate accHolderDob;
	int accHolderAge;
	
	
	public void setBankAcc(int x, String y, double z, int year1, int month1, int date1, String dob) //formal arguments
	{
		accNo = x;
		accName = y;
		accBalance = z;
		accOpenedDate = LocalDate.of(year1, month1, date1);
		accHolderDob = LocalDate.parse(dob);
		accHolderAge = LocalDate.now().getYear()-accHolderDob.getYear();
	}
	
	public void printAccount()
	{
		System.out.println("Account Number: "+accNo);
		System.out.println("Account Holder Name: "+accName);
		System.out.println("Account Balance: "+accBalance);
		System.out.println("Account Opened Date: "+accOpenedDate);
		System.out.println("Account Holder Age: "+accHolderAge+" years old");
		System.out.println("******************************");
	}
	
	public void withdrawl(double amtToWithdraw)
	{
		if(amtToWithdraw > accBalance)
		{
			throw new RuntimeException("Insufficent funds.....");
		}
		System.out.println(accName+" is withdrawing "+amtToWithdraw+" Rupees...");
		accBalance = accBalance-amtToWithdraw;
	}
	
	public void deposit(double amtToDeposit)
	{
		System.out.println(accName+" is DEPOSITING"+amtToDeposit+" Rupees...");
		accBalance = accBalance-amtToDeposit;
	}
}