import java.io.PrintWriter;

public class DataTypesTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		byte rollNumber = 101;
		System.out.println("value of rollnumber:"+rollNumber);
		System.out.println("Byte Max value is"+Byte.MAX_VALUE);
		System.out.println("Byte Min value is"+Byte.MIN_VALUE);
		System.out.println("Byte size is"+Byte.SIZE+" bits");
		System.out.println("**********************************");
		
		short regNo = 25456;
		System.out.println("value of registration number:"+regNo);
		System.out.println("Short Max value is"+Short.MAX_VALUE);
		System.out.println("Short Min value is"+Short.MIN_VALUE);
		System.out.println("Short size is"+Short.SIZE+" bits");
		System.out.println("**********************************");
		
		int mobNo = 770245444;
		System.out.println("value of mobile number:"+mobNo);
		System.out.println("Integer Max value is"+Integer.MAX_VALUE);
		System.out.println("Integer Min value is"+Integer.MIN_VALUE);
		System.out.println("Integer size is"+Integer.SIZE+" bits");
		System.out.println("**********************************");
		
		long uidNo = 723052704093l;
		System.out.println("value of mobile number:"+uidNo);
		System.out.println("Long Max value is"+Long.MAX_VALUE);
		System.out.println("Long Min value is"+Long.MIN_VALUE);
		System.out.println("Long size is"+Long.SIZE+" bits");
		System.out.println("**********************************");
		
		float intRate = 3.5f;
		System.out.println("ROI on savings account:"+intRate);
		System.out.println("Float Max value is"+Float.MAX_VALUE);
		System.out.println("Float Min value is"+Float.MIN_VALUE);
		System.out.println("Float size is"+Float.SIZE+" bits");
		System.out.println("**********************************");
		
		double velocity = 12.5f;
		System.out.println("velocity of light:"+velocity);
		System.out.println("Double Max value is"+Double.MAX_VALUE);
		System.out.println("Double Min value is"+Double.MIN_VALUE);
		System.out.println("Double size is"+Double.SIZE+" bits");
		System.out.println("**********************************");
		
		boolean isCertified = false; 
		System.out.println("Certication is "+isCertified);
		//System.out.println("size of boolean is "+Boolean.);
		
		char variable = 'S';
		System.out.println("Value of variable is "+variable);
		System.out.println("Size of char is "+Character.SIZE+" bits");
		
		char aa1='\u0905';
		char aa2='\u2665';
		char aa3='\u263A';
		PrintWriter myWriter = new PrintWriter(System.out,true);
		myWriter.println("value of aa= "+aa1);
		myWriter.println("value of aa= "+aa2);
		myWriter.println("value of aa= "+aa3);
	}

}
