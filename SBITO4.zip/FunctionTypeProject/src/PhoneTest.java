
public class PhoneTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Phone p1 = new Phone();
		p1.dial();
		byte police=100;
		p1.dial(police);
		p1.dial((byte)101);
		
		short rlwy=139;
		p1.dial(rlwy);
		
		short sh=25456;
		byte by=108;
		long l=123456789l;
		
		p1.dial(by, l);
		p1.dial(by, sh);
		p1.dial(l, by);
		
	}

}

class Phone
{
	void dial()
	{
		System.out.println("dialing nowhere....");
	}
	
	void dial(byte intercom)
	{
		System.out.println("dialing(byte) to intercomm no :"+intercom);
	}
	
	void dial(short intercom)
	{
		System.out.println("dialing(short) to helpline no :"+intercom);
	}
	
	void dial(byte  x, short y)
	{
		System.out.println("dialing(byte short) to nos :"+x+" and "+y);
	}
	
	void dial(byte  x, long y)
	{
		System.out.println("dialing(byte long) to nos :"+x+" and "+y);
	}
	
	void dial(long  x, byte y)
	{
		System.out.println("dialing(long byte) to nos :"+x+" and "+y);
	}
}