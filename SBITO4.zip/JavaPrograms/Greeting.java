class Greeting
{
   public static void main(String args[])
   {
   System.out.println("Hello world Java..Greeting class.");
   }
}

class Greet
{
   public static void main(String args[])
   {
   System.out.println("Hello...Greet class...");
   }
}	

class Welcome
{
   public static void main(String args[])
   {
   System.out.println("Hello..Welcome class...");
   //transfer();
   }
}

class FundTransfer
{
   public void transfer()
   {
      System.out.println("Transferring Funds...");
    }
}
		