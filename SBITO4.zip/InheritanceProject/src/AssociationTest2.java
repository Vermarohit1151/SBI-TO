
public class AssociationTest2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Ac acObj = new Ac();
		acObj.setMachineType("split");
		acObj.setCompName("LG");
		//CoolBreeze cb = 
		
	}

}

class Machine
{
	String machineType;

	public String getMachineType() {
		return machineType;
	}

	public void setMachineType(String machineType) {
		this.machineType = machineType;
	}

	@Override
	public String toString() {
		return "Machine [machineType=" + machineType + "]";
	}
	
	
}

class Ac extends Machine
{
	String compName;
	Condensor cs1 = new Condensor();
	
	public String getCompName() {
		return compName;
	}
	public void setCompName(String compName) {
		this.compName = compName;
	}
	public Condensor getCs1() {
		return cs1;
	}
	public void setCs1(Condensor cs1) {
		this.cs1 = cs1;
	}
	@Override
	public String toString() {
		return "Ac [compName=" + compName + ", cs1=" + cs1 + ", machineType=" + machineType + "]";
	}
	
	CoolBreeze air(Electricity volts, int temp)
	{
		CoolBreeze cb = new CoolBreeze();
		cb.setBrand(compName);
		return cb;
		
	}
	
}

class Electricity
{
	int volts;
	
	public int getVolts() {
		return volts;
	}

	public void setVolts(int volts) {
		this.volts = volts;
	}

	@Override
	public String toString() {
		return "Electricity [volts=" + volts + "]";
	}
	
	
}

class Condensor
{
	int capacity;

	public int getCapacity() {
		return capacity;
	}

	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}

	@Override
	public String toString() {
		return "Condensor [capacity=" + capacity + "]";
	}
	
}

class CoolBreeze
{
		String brand;
		String filterType;
		int temp;
		

		public int getTemp() {
			return temp;
		}

		public void setTemp(int temp) {
			this.temp = temp;
		}

		public String getFilterType() {
			return filterType;
		}

		public void setFilterType(String filterType) {
			this.filterType = filterType;
		}

		public String getBrand() {
			return brand;
		}

		public void setBrand(String brand) {
			this.brand = brand;
		}

		@Override
		public String toString() {
			return "CoolBreeze [brand=" + brand + ", filterType=" + filterType + ", temp=" + temp + "]";
		}

		
}