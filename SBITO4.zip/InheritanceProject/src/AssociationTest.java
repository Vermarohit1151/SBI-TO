
public class AssociationTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Person2 p1 = new Person2("anil",21,0, 0, "male", 0, 0);
	}

}

class BankAccount
{
	String bankName;
	String ifscCode;
	String bankLoc;
	
	BankAccount()
	{
		
	}
	public BankAccount(String bankName, String ifscCode, String bankLoc) {
		super();
		this.bankName = bankName;
		this.ifscCode = ifscCode;
		this.bankLoc = bankLoc;
	}
	@Override
	public String toString() {
		return "BankAccount [bankName=" + bankName + ", ifscCode=" + ifscCode + ", bankLoc=" + bankLoc + "]";
	}
	
	
	
}

class Term{
	int year=3;

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	@Override
	public String toString() {
		return "Term [year=" + year + "]";
	}
	
}
class Statement {
   double  valueOfYear1;
   double valueOfYear2;
   double valueOfYear3;
@Override
public String toString() {
	return "Statement [valueOfYear1=" + valueOfYear1 + ", valueOfYear2=" + valueOfYear2 + ", valueOfYear3="
			+ valueOfYear3 + "]";
}
   
}


class Person2
{
	String pName;
	int pAge;
	char pGender;
	fdAccount fd1;
	
	public Person2(String pName, int pAge, char pGender, int accNo, String accName, double amount,
			double rateOfInt) {
		super();
		this.pName = pName;
		this.pAge = pAge;
		this.pGender = pGender;
		fd1 = new fdAccount(accNo, accName, amount, rateOfInt);
	}
	
	Statement  calc(Term t) {
		double intrt = (fd1.principalAmt*t.year*fd1.rateOfInt)/100.0;   //fd1.t.year
		
		Statement st = new Statement();
		st.valueOfYear1=intrt;
		st.valueOfYear2=intrt;//cmp formula
		st.valueOfYear3=intrt;//cmp formula
		return st;
	}
	void printPerson()
	{
		System.out.println("Person Name: "+pName);
		System.out.println("Person age: "+pAge);
		System.out.println("Person Gender: "+pGender);
		fd1.printAccDetails();
		
	}
	
}

class fdAccount extends BankAccount
{
	int accNo;
	String accName;
	double principalAmt;
	double rateOfInt;
	
	public fdAccount(int accNo, String accName,
			double amount, double rateOfInt) {
		//super(bankName, ifscCode, bankLoc);
		this.accNo = accNo;
		this.accName = accName;
		this.rateOfInt = rateOfInt;
	}
	
	public fdAccount(String bankName, String ifscCode, String bankLoc, int accNo, String accName,
			double amount, double rateOfInt) {
		super(bankName, ifscCode, bankLoc);
		this.accNo = accNo;
		this.accName = accName;
		this.rateOfInt = rateOfInt;
	}
	@Override
	public String toString() {
		return "SavingsAccount [accNo=" + accNo + ", accName=" + accName + ", rateOfInt=" + rateOfInt + ", bankName="
				+ bankName + ", ifscCode=" + ifscCode + ", bankLoc=" + bankLoc + "]";
	}
	
	
	void printAccDetails()
	{
		System.out.println("Account Number :"+accNo);
		System.out.println("Account Name :"+accName);
		System.out.println("Rate of Interest :"+rateOfInt);
		
	}
}


