
public class GirlTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Girl g1 = new Girl("Srinidhi");
		Girl g2 = new Girl("Rushika");
		Girl g3 = new Girl("Likitha");
		
		g1.selftalk();
		g1.talk(10);
		g1.talk(20, g2);
		g1.gossip(g2, g3);
		g2.gossip(g1, g3);
		g3.gossip(g2, g1);
		g2.talk(15, g3);
		System.out.println("----------------------");
		String sms = g3.grpChat(g2, g1);
		System.out.println("----------------------");
		System.out.println("MESSAGE :"+sms);
	}

}

class Girl
{
	String girlName;

	public Girl(String girlName) {
		super();
		this.girlName = girlName;
	}
	
	void selftalk()
	{
		System.out.println(girlName+"is having self talk");
	}
	
	void talk(int x)
	{
		System.out.println(girlName+"is talking for "+x+" minutes");
	}
	
	void talk(int x, Girl gObj)
	{
		System.out.println(girlName+"is talking for "+x+" minutes with "+gObj.girlName);
	}
	
	void gossip(Girl gObj1, Girl gObj2)
	{
		System.out.println(girlName+"is talking with "+gObj1.girlName+" and "+gObj2.girlName);
	}
	
	String grpChat(Girl gObj1, Girl gObj2)
	{
		System.out.println(girlName+"is talking with "+gObj1.girlName+" and "+gObj2.girlName);
		return "Groupchat is gng on...";
	}
}