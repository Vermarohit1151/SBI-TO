
public class InheritanceTest2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Person p1 = new Person("srinidhi",18,'f');
		System.out.println("Person details: "+p1);
		
		Student s1 = new Student("srinidhi",18,'f',"S101","Gitams","EEE");
		System.out.println("Student details: "+s1);
		
		Employee e1 = new Employee("srinidhi",18,'f',"S101","Gitams","EEE","E101","Deloitte","developer",45689.23);
		System.out.println("Employee details: "+e1);
		
	}

}

interface Living
{
	void live();
}
 class Person implements Living
{
	String pName;
	int pAge;
	char pGender;
	public Person(String pName, int pAge, char pGender) {
		super();
		this.pName = pName;
		this.pAge = pAge;
		this.pGender = pGender;
	}
	@Override
	public String toString() {
		return "Person [pName=" + pName + ", pAge=" + pAge + ", pGender=" + pGender + "]";
	}
	@Override
	public void live() {
		// TODO Auto-generated method stub
		
	}
		
}

 interface Studying
 {
	void study(); 
 }
 interface Chatting
 {
	 void chat();
 }
 interface Solving
 {
	 void solve();
 }
class Student extends Person implements Studying, Chatting, Solving
{
	String rollNo;
	String collName;
	String stream;
	
	
	public Student(String pName, int pAge, char pGender, String rollNo, String collName, String stream) {
		super(pName, pAge, pGender);
		this.rollNo = rollNo;
		this.collName = collName;
		this.stream = stream;
	}


	@Override
	public String toString() {
		return "Student [rollNo=" + rollNo + ", collName=" + collName + ", stream=" + stream + ", pName=" + pName
				+ ", pAge=" + pAge + ", pGender=" + pGender + "]";
	}


	@Override
	public void study() {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void solve() {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void chat() {
		// TODO Auto-generated method stub
		
	}
		
}

interface Working
{
	void work();
}
interface SigningIn
{
	void signIn();
}
interface SigningOut
{
	void signOut();
}
class Employee extends Student implements Working, SigningIn, SigningOut
{
	String empNo;
	String compName;
	String empDesg;
	double empSal;
	public Employee(String pName, int pAge, char pGender, String rollNo, String collName, String stream, String empNo,
			String compName, String empDesg, double empSal) {
		super(pName, pAge, pGender, rollNo, collName, stream);
		this.empNo = empNo;
		this.compName = compName;
		this.empDesg = empDesg;
		this.empSal = empSal;
	}
	@Override
	public String toString() {
		return "Employee [empNo=" + empNo + ", compName=" + compName + ", empDesg=" + empDesg + ", empSal=" + empSal
				+ ", rollNo=" + rollNo + ", collName=" + collName + ", stream=" + stream + ", pName=" + pName
				+ ", pAge=" + pAge + ", pGender=" + pGender + "]";
	}
	@Override
	public void signOut() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void signIn() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void work() {
		// TODO Auto-generated method stub
		
	}
	
	
}