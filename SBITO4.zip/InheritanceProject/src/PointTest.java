
public class PointTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Point2D p1 = new Point2D(10,20);
		System.out.println("p1 "+p1); // +symbol internally calls tostring func
		
		System.out.println("-------------------------");
		
		Point3D p2 = new Point3D(50,60,70);
		System.out.println("p2 : "+p2);
		
		System.out.println("-------------------------");
		ColoredPoint2D cp1 = new ColoredPoint2D(10,20,"orange");
		System.out.println("cp1 : "+cp1);
		System.out.println("-------------------------");
		ColoredPoint3D cp2 = new ColoredPoint3D(50,60,70,"blue");
		System.out.println("cp1 : "+cp1);
//		GrandFather gf = new GrandFather("sadf");
//		System.out.println("--------------------------");
//		Father f = new Father(12);
//		System.out.println("--------------------------");
//
//		Child c = new Child();
//		System.out.println("--------------------------");

	}

}

class Point2D
{
	int x;
	int y;
	public Point2D(int x, int y) {
		super();
		this.x = x;
		this.y = y;
	}
	
	@Override
	public String toString() {
		return "Point2D [x=" + x + ", y=" + y + "]";
	}
}

class ColoredPoint2D extends Point2D
{
	String color;
	public ColoredPoint2D(int x, int y, String color) {
		super(x, y);
		this.color = color;
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "ColoredPoint2D [x="+super.x+", y="+super.y+ ", color=" + color + "]";
	}
	
	
}

class Point3D extends Point2D
{
	private int z;

	public Point3D(int x, int y, int z) {
		super(x, y);
		this.z = z;
	}

	@Override
	public String toString() {
		return "Point3D [x=" + super.x + ", y=" + super.y + ", z=" + z + "]";
	}

	
	
	
}

class ColoredPoint3D extends Point3D
{
	String color;
	public ColoredPoint3D(int x, int y, int z, String color) {
		super(x, y, z);
		this.color = color;
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "ColoredPoint3D [toString()=" + super.toString() + ", color=" + color + "]";
	}
	
	
}
class GrandFather
{
	GrandFather(String z)
	{
		System.out.println("Entered GrandFather Cons....");
	}
}
class Father extends GrandFather
{
	Father(int x)
	{
	super("dhfjdsh");
	System.out.println("\tEntered Father Cons....");
	}
}
class Child extends Father
{
	Child()
	{
	super(25);
	System.out.println("\t\tEntered Father Cons....");
	}
}