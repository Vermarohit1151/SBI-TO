
public class ThreadTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Car car1 = new Car("BMW");
		Train t=new Train();
		Sumo s = new Sumo();
		Chalk chalk1 = new Chalk("Green");
		Chalk chalk2 = new Chalk("pink");
//		Thread t1 = new Thread(chalk1);
		
		new Thread(chalk1).start();	
		
		new Thread(chalk2).start();	
		car1.start();
		//t1.start();
//		t.start();
//		s.start();
		
		
	}

}
class Car extends Thread
{
	String model;
	
	public Car(String model) {
		super();
		this.model = model;
	}

	public void run()
	{
		for(int i=1; i<=150; i++)
		{
			System.out.println(model+" car at "+i+"km/hr");
		}
			
	}
}

class Train extends Thread
{
	public void run()
	{
		for(int i=1; i<=250; i++)
		{
			System.out.println("Train at "+i+"km");
		}
			
	}
}

class Sumo extends Thread
{
	public void run()
	{
		for(int i=1; i<=350; i++)
		{
			System.out.println("\t\tSumo at "+i+"km");
		}
			
	}
}

class Stone
{
	
}
class Chalk extends Stone implements Runnable
{
	String chalkColor;

	public Chalk(String chalkColor) {
		super();
		this.chalkColor = chalkColor;
	}
	public void run()
	{
		for(int i=1; i<=350; i++)
		{
			System.out.println("\tWriting with "+chalkColor+" chalk");
		}
			
	}
	
}