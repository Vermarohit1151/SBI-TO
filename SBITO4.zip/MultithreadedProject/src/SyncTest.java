
public class SyncTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BankAccount baObj = new BankAccount(101, "sri", 50000);
		
		Teller t1 = new Teller("Arun", 5000, baObj);
		Teller t2 = new Teller("\tSruthi", 8000, baObj);
		Teller t3 = new Teller("\t\tHima", 10000, baObj);
		
		t1.start();
		t2.start();
		t3.start();
		
		try {
			t1.join();
			t2.join();
			t3.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}

class Teller extends Thread
{
	String tellerName;
	double cashToDep;
	BankAccount baRef;
	
	public Teller(String tellerName, double cashToDep, BankAccount baRef) {
		super();
		this.tellerName = tellerName;
		this.cashToDep = cashToDep;
		this.baRef = baRef;
	}
	
	public void run()
	{
		System.out.println("run block started");
		System.out.println(tellerName+" is depositing cash "+cashToDep);
		baRef.deposit(tellerName, cashToDep);
		System.out.println("run block ended");
	}
}

class BankAccount
{
	//private static final Exception  = null;
	private int accNo;
	private String accName;
	private double accBal;
	public BankAccount(int accNo, String accName, double accBal) //throws OpeningBalanceException, NegativeAccountNumberException, InvalidAccountNameException
	{
		super();
		System.out.println("entered BankAccount cons.........");
		//System.out.println("assigning account number.........");
		this.accNo = accNo;
		//System.out.println("assigning account name.........");
		this.accName = accName;
		//System.out.println("Assigning account balance.........");
		this.accBal = accBal;	
		System.out.println("BankAccount cons is ended.........");
	}
	
	void withdraw(double amtToWdrw)
	{
			System.out.println("withdrawing the amount :"+amtToWdrw);
			accBal = accBal-amtToWdrw;
	}
	void deposit(String tellerName, double amtToDep) 
		{
//		System.out.println("Line1...............");
//		System.out.println("Line2...............");
//		System.out.println("Line3...............");
//		synchronized(this)
//		{
			System.out.println(tellerName+" depositing the amount :"+amtToDep);
			double currBal=getAccBal();
			System.out.println(tellerName+" finding the curr balance as"+currBal);
			double newBal = accBal+amtToDep;
			System.out.println(tellerName+" calculating the total amount as:"+newBal);			
			System.out.println(tellerName+" setting the new balance");
			setAccBal(newBal);
			System.out.println("The new balance is: "+newBal);
//		}
//		System.out.println("Line4...............");
//		System.out.println("Line5...............");
//		System.out.println("Line6...............");
		}
			
	public double getAccBal() {
		return accBal;
	}

	public void setAccBal(double accBal) {
		this.accBal = accBal;
	}

	@Override
	public String toString() {
		return "BankAccount [accNo=" + accNo + ", accName=" + accName + ", accBal=" + accBal + "]";
	}
	
	
}