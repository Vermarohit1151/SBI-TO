import java.awt.FlowLayout;

import javax.swing.JFrame;
import javax.swing.JTextField;

public class FrameTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		JFrame jf1 = new JFrame();
//		jf1.setLocation(200,300);
//		jf1.setSize(400,400);
//		jf1.setTitle("Srilakshmi");
//		jf1.setVisible(true);
//		//jf1.setBackground("yellow");
		System.out.println("Begin of main.........");
		MyFrame mf1 = new MyFrame(200,400,100,100,"MyCar");
		MyFrame mf2 = new MyFrame(300,500,200,300,"MyBike");
		MyFrame mf3 = new MyFrame(400,600,300,400,"MyVan");
		new Thread(mf1).start();
		new Thread(mf2).start();
		new Thread(mf3).start();
		
		System.out.println("End of main.........");
	}

}

class MyFrame extends JFrame implements Runnable
{
	JTextField ta = new JTextField(20);
	String title;
	MyFrame(int w, int h, int x, int y, String title)
	{
		super.setSize(w, h);
		super.setLocation(x, y);
		super.setTitle(title);
		this.title=title;
		super.setVisible(true);
		super.setLayout(new FlowLayout());;
		super.add(ta);
		//super.setDefaultCloseOperation(EXIT_ON_CLOSE);
		super.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
	}
	
	public void run()
	{
		for(int i=1;i<=100;i++)
		{
			ta.setText(title+" is running...."+i);
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}