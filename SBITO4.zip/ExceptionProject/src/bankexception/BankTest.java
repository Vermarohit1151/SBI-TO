package bankexception;

public class BankTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BankAccount ba1 = null;
		try {
			System.out.println("entered try block for object creation");
			ba1 = new BankAccount(-101,"anil kumar",10000);
			System.out.println(ba1);
			} 
		catch (OpeningBalanceException e) {
			System.out.println("entered catch block - OpeningBalanceException");
			System.out.println("some problem during acocunt creation :"+e);
			//e.printStackTrace();
		}
		catch (NegativeAccountNumberException e) {
			System.out.println("entered catch block - NegativeAccountNumberException");
			System.out.println("Warning Message :"+e);
			//e.printStackTrace();
		} catch (InvalidAccountNameException e) {
			System.out.println("entered catch block - InvalidAccountNameException");
			System.out.println("Warning Message :"+e);
			e.printStackTrace();
		}
		finally
		{
			System.out.println("All connections are closed...finally block is executed");
		}
		
		ba1.deposit(5000);
		System.out.println(ba1);
		System.out.println("amount deposit is done...");
		//e.printStackTrace();
		
		System.out.println("calling withddraw function...");
		ba1.withdraw(5000);
		System.out.println("withdrawl is complete...");
		System.out.println("BankObject :"+ba1);
	}

}

class BankAccount
{
	//private static final Exception  = null;
	private int accNo;
	private String accName;
	private double accBal;
	public BankAccount(int accNo, String accName, double accBal) throws OpeningBalanceException, NegativeAccountNumberException, InvalidAccountNameException
	{
		super();
		System.out.println("entered BankAccount cons.........");
		if(accNo>0)
		{
		System.out.println("assigning account number.........");
		this.accNo = accNo;
		}
		else
			throw new NegativeAccountNumberException("Please check and enter correct account number...");
		if(accName.matches("[a-zA-Z ]*"))
		{
		System.out.println("assigning account name.........");
		this.accName = accName;
		}
		else
			throw new InvalidAccountNameException("Please check and enter valid account Holder Name...");
		if (accBal>3000)
		{
			System.out.println("Assigning account balance.........");
			this.accBal = accBal;	
		}
		else
			throw new OpeningBalanceException("New account can be opened with min balance of 3000 and above");
		
		System.out.println("BankAccount cons is ended.........");
	}
	
	void withdraw(double amtToWdrw)
	{
		if(accBal<amtToWdrw)
		{
			InsufficientBalanceException e = new InsufficientBalanceException("Insufficient balance in source acc..pls check..");
			throw e;
		}
		else
		{
			System.out.println("withdrawing the amount :"+amtToWdrw);
			accBal = accBal-amtToWdrw;
		}
	}
		void deposit(double amtToDep) 
		{
			if(amtToDep>=50000)
			{
				IncomeProofException e = new IncomeProofException("Please submit PAn card for deposit of 50000 & above ");
				throw e;
			}
			else
			{
				System.out.println("depositing the amount :"+amtToDep);
				accBal = accBal-amtToDep;
			}
			
	}
	
	@Override
	public String toString() {
		return "BankAccount [accNo=" + accNo + ", accName=" + accName + ", accBal=" + accBal + "]";
	}
	
	
}