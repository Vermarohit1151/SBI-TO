package bankexception;

public class NegativeAccountNumberException extends Exception
{

	public NegativeAccountNumberException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
