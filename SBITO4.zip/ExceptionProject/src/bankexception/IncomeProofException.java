package bankexception;

public class IncomeProofException extends RuntimeException {

	public IncomeProofException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
