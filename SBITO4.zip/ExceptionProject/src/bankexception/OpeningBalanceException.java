package bankexception;
//checked exception
public class OpeningBalanceException extends Exception {

	public OpeningBalanceException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
