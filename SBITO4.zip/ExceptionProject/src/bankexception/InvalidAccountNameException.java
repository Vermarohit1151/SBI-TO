package bankexception;

public class InvalidAccountNameException extends Exception
{

	public InvalidAccountNameException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
