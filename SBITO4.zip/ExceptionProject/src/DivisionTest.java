import java.util.InputMismatchException;
import java.util.Scanner;

public class DivisionTest {

	public static void main(String[] args) {
		
		System.out.println("Begin of mian.....");
		Scanner s1 = new Scanner(System.in);
		Scanner s2 = new Scanner(System.in);
				
		try
		{
			System.out.println("Enter numerator :");
			int x=s1.nextInt();
			System.out.println("Enter denominator :");
			int y=s1.nextInt();
			int z=x/y;
			System.out.println("value of z :"+z);
		}
		catch(ArithmeticException e)
		{
			System.out.println("Cannot divide by zero....");
		}
		catch(InputMismatchException e)
		{
			System.out.println("please input valid value...");
		}
		System.out.println("End of mian.......");
	}

}
