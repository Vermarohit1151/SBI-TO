package jungle.tree;

public class PalmTree {

}
