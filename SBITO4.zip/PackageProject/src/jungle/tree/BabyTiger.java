package jungle.tree;

import jungle.mountain.BengalTiger;

class BabyBengalTiger extends BengalTiger
{
	void printingAge2()
	{
		System.out.println("Tiger is roaring.....");
		System.out.println("defaultAge :"+defaultAge);
		System.out.println("privateAge :"+privateAge);
		System.out.println("publicAge :"+publicAge);
		System.out.println("protectedAge :"+protectedAge);		
	}
}