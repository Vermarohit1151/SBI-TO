package jungle.river;

public class Fish {
	public void swim() {
		System.out.println("Fish is swimming");
	}

}
