package jungle.useit;

import jungle.cave.Tiger;
import jungle.cave.WhiteTiger;
import jungle.river.*;
import jungle.mountain.*;

public class JungleTest {

	public static void main(String[] args) {
		System.out.println("Begin main...");
		Tiger t = new Tiger();
		t.roar();
		System.out.println("----------------"); //TDD
		WhiteTiger wt = new WhiteTiger();
		wt.roar();
		
		Fish f = new Fish();
		f.swim();
		
		Monkey m = new Monkey();
		m.jump();
	}
	
}


/*
  	
 		pack1.pack2.pack3
		ClassName 		- SavingsAccount
		variableName 	- rollNumber
		methodName 		- setLookAndFeel()
		CONSTANT 		- PI
		

*/