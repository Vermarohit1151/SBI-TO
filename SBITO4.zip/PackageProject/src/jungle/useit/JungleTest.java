package jungle.useit;

import jungle.cave.Tiger;
import jungle.cave.WhiteTiger;

public class JungleTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Begin main...");
		Tiger t = new Tiger();
		t.roar();
		System.out.println("------------------------");
		WhiteTiger wt = new WhiteTiger();
		wt.roar();
	}

}
