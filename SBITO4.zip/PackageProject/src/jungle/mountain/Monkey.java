package jungle.mountain;

import jungle.cave.Tiger;

public class Monkey {
	Tiger t = new Tiger();
	
	public void jump() {
		t.roar();
		try {
		Thread.sleep(1000);
		}
		catch(InterruptedException e) {
			System.out.println("Thread was interrupted with "+e);
		}
		System.out.println("Monkey jumps after hearing the Tiger roar....");
	}
}
