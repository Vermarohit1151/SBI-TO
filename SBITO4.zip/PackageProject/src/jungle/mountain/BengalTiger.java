package jungle.mountain;

import jungle.cave.Tiger;

public class BengalTiger extends Tiger {

	void printingAge()
	{
		System.out.println("Tiger is roaring.....");
		System.out.println("defaultAge :"+defaultAge);
		System.out.println("privateAge :"+privateAge);
		System.out.println("publicAge :"+publicAge);
		System.out.println("protectedAge :"+protectedAge);		
	}
}

