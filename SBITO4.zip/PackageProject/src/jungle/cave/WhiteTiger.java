package jungle.cave;

public class WhiteTiger extends Tiger {
	
	
	public WhiteTiger() {
		 
		// TODO Auto-generated constructor stub
	}

	@Override
	public void roar() {
		// TODO Auto-generated method stub
		System.out.println("WhiteTiger is roaring.........");
		System.out.println("Tiger is roaring.....");
		System.out.println("defaultAge :"+defaultAge);
		System.out.println("privateAge :"+privateAge);
		System.out.println("publicAge :"+publicAge);
		System.out.println("protectedAge :"+protectedAge);		
	}
	
}

class Monkey1
{
	void printAge1()
	{
		Tiger t = new Tiger();
		System.out.println("Tiger is roaring.....");
		System.out.println("defaultAge :"+t.defaultAge);
		System.out.println("privateAge :"+t.privateAge);
		System.out.println("publicAge :"+t.publicAge);
		System.out.println("protectedAge :"+t.protectedAge);		
	}
	
}