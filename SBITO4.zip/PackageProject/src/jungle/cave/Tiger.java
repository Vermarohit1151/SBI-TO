package jungle.cave;

public class Tiger {
	int defaultAge = 1;
	private int privateAge=2;
	public int publicAge=3;
	protected int protectedAge=4;
	public void roar() {
				
		System.out.println("Tiger is roaring.....");
		System.out.println("defaultAge :"+defaultAge);
		System.out.println("privateAge :"+privateAge);
		System.out.println("publicAge :"+publicAge);
		System.out.println("protectedAge :"+protectedAge);		
	}

	public Tiger() {
		System.out.println("Tiger cons.........");
		}

}

class Monkey
{
	void printAge()
	{
		Tiger t = new Tiger();
		System.out.println("Tiger is roaring.....");
		System.out.println("defaultAge :"+t.defaultAge);
		System.out.println("privateAge :"+t.privateAge);
		System.out.println("publicAge :"+t.publicAge);
		System.out.println("protectedAge :"+t.protectedAge);		
	}
	
}