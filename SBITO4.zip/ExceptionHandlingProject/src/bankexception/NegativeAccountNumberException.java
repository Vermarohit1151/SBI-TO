package bankexception;

public class NegativeAccountNumberException extends Exception {
	public NegativeAccountNumberException(String e) {
		super(e);
	}
}
