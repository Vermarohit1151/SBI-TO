package bankexception;

public class IncomeProofException extends RuntimeException {
	public IncomeProofException(String msg) {
		super(msg);
	}
}
