package bankexception;

public class InvalidNameException extends Exception {
	public InvalidNameException(String e) {
		super(e);
	}
}
