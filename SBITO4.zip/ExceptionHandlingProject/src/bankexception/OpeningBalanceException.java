package bankexception;

public class OpeningBalanceException extends Exception{
	public OpeningBalanceException(String msg) {
		super(msg);
	}
}
