import bankexception.IncomeProofException;
import bankexception.InsufficientBalanceException;
import bankexception.InvalidNameException;
import bankexception.NegativeAccountNumberException;
import bankexception.OpeningBalanceException;

public class BankTest {

	public static void main(String[] args)  {
		// TODO Auto-generated method stub
		
		try {
			BankAccount baObj1 = new BankAccount(11267,"Rohit Kumar Verma", 34000);
			System.out.println("----------------------------------");
			baObj1.withdraw(32500);
			baObj1.deposit(7500);
		}
		
//		catch(OpeningBalanceException e) {
//			System.out.println("Some problem Occured "+e);
//		}
//		catch(NegativeAccountNumberException e) {
//			System.out.println("Some problem Occured "+e);
//		}
//		catch(InvalidNameException e) {
//			System.out.println("Some problem Occured "+e);
//		}
		
		catch(Exception e) {
			System.out.println("Some Problem Occured "+e);
		}
	}

}

class BankAccount{
	private int accountNumber;
	private String accountHolder;
	private int accountBalance;
	
	public BankAccount(int accountNumber, String accountHolder, int accountBalance) throws OpeningBalanceException,InvalidNameException,NegativeAccountNumberException{
		super();
		
		System.out.println("Constructor Start");
		if(accountHolder.matches("[a-zA-Z\\s]+")){
			System.out.println("Account Holder Name Set");
			this.accountHolder = accountHolder;
		}
		else 
		{
			throw new InvalidNameException("Name cannot contain numbers or special characters");
		}
		
		
		if(accountNumber<0)
		{
			throw new NegativeAccountNumberException("Account Number cannot be Negative! Pls check inputs again");
		}
		
		else
		{
			System.out.println("Account number created");
			this.accountNumber = accountNumber;
		}
		
		
		if(accountBalance < 3000) {
			throw new OpeningBalanceException("Your opening account balance should be greater than 3000");
		}
		else 
		{
			System.out.println("Crediting Account Balance with "+accountBalance);
			this.accountBalance = accountBalance;
		}
		
		System.out.println("Constructor end");
	}
	
	public void deposit(double amtToDeposit) {
		if(amtToDeposit>50000) {
			IncomeProofException e = new IncomeProofException("Please provide a valid Income proof for the depoist");
			throw e;
		}
		else {
			System.out.println("Starting Deposit Txn of Amount "+amtToDeposit);
			this.accountBalance += amtToDeposit;
			System.out.println("Current Balance "+accountBalance);
		}
		
	}
	public void withdraw(double amtToWithdraw) {
		System.out.println("Starting withdraw Txn of Amount "+amtToWithdraw);
		if(amtToWithdraw < accountBalance) {
			this.accountBalance -= amtToWithdraw; 
			System.out.println("Transaction Successful");
			System.out.println("Current Balance "+accountBalance);
		}
		else {
				InsufficientBalanceException err = new InsufficientBalanceException("Insufficent Bank Balance to Withdraw");
				throw err;
		}
	}
}


