import java.util.InputMismatchException;
import java.util.Scanner;

public class DivisionTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try (Scanner sc = new Scanner(System.in)) {
			System.out.println("Begin main...");
			try {
			int x = sc.nextInt();
			System.out.println("X= "+x);
			int y = sc.nextInt();
			System.out.println("Y= "+y);
			
			int z = x/y;
			System.out.println("Z= "+z);
			}
			catch(ArithmeticException e) {
				System.out.println("Cannot divide by zero");
			}
			catch(InputMismatchException e) {
				System.out.println("Input cannot be String ");
			}
		}
		System.out.println("End main");
	}

}
