import java.util.HashSet;
import java.util.Iterator;
import java.util.Objects;

public class HashSetTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Book b1 = new Book("Ingnited Minds","APJ Kalam",205.56f,101);
		Book b2 = new Book("you can win","shiv kare",305.06f,102);
		Book b3 = new Book("Head First Java","James Gosling",456.50f,103);
		
		HashSet<Book> bookSet = new HashSet<Book>();
		System.out.println("adding book1....");
		bookSet.add(b1);
		System.out.println("adding book2....");
		bookSet.add(b2);
		System.out.println("adding book3....");
		bookSet.add(b3);
		
		Iterator<Book> itr = bookSet.iterator();
		while(itr.hasNext())
		{
			System.out.println("Book details: "+itr.next());
			System.out.println("--------------------------");
		}
	}

}

class Book
{
	String bookName;
	String bookAuthor;
	float bookPrice;
	int bookIsdnNo;
	public Book(String bookName, String bookAuthor, float bookPrice, int bookIsdnNo) {
		super();
		this.bookName = bookName;
		this.bookAuthor = bookAuthor;
		this.bookPrice = bookPrice;
		this.bookIsdnNo = bookIsdnNo;
	}
	@Override
	public String toString() {
		return "Book [bookName=" + bookName + ", bookAuthor=" + bookAuthor + ", bookPrice=" + bookPrice
				+ ", bookIsdnNo=" + bookIsdnNo + "]";
	}
	
	@Override
	public int hashCode() {
		return Objects.hash(bookAuthor, bookName);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Book other = (Book) obj;
		return Objects.equals(bookAuthor, other.bookAuthor) && Objects.equals(bookName, other.bookName);
	}
	
	
	
	
}