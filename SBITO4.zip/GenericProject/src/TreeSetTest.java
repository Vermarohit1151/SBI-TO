import java.util.Iterator;
import java.util.TreeSet;

public class TreeSetTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Atom a1 = new Atom("Hydrogen",21,1.008f,"H");
		Atom a2 = new Atom("Helium",32,4.003f,"He");
		Atom a3 = new Atom("Lithium",43,6.341f,"Li");
		System.out.println("Content is ready....");
		
		TreeSet<Atom> atomSet = new TreeSet<Atom>();
		System.out.println("Container is ready...");
		System.out.println("adding 1st element....");
		atomSet.add(a1);
		System.out.println("adding 2nd element....");
		atomSet.add(a2);
		
		System.out.println("adding 3rd element....");
		atomSet.add(a3);
		System.out.println("adding 4th element....");
		atomSet.add(new Atom("Berylium",24,9.12f,"Be"));
		System.out.println("elements are added....");
		
		Iterator<Atom> itr = atomSet.iterator();
		while (itr.hasNext())
		{
			
			System.out.println("Element is : "+itr.next());
			System.out.println("------------------------");
		}
}
}
class Atom implements Comparable<Atom>
{
	String atomName;
	int atomNo;
	float atomWeight;
	String atomFormula;
	public Atom(String atomName, int atomNo, float atomWeight, String atomFormula) {
		super();
		this.atomName = atomName;
		this.atomNo = atomNo;
		this.atomWeight = atomWeight;
		this.atomFormula = atomFormula;
	}
	@Override
	public String toString() {
		return "Atom [atomName=" + atomName + ", atomNo=" + atomNo + ", atomWeight=" + atomWeight + ", atomFormula="
				+ atomFormula + "]";
	}
//	@Override
//	public int compareTo(Atom o) {
//		System.out.println("Comparing "+atomNo+" with "+o.atomNo);
//		return Integer.compare(atomNo, o.atomNo);
//	}
	
	@Override
	public int compareTo(Atom o) {
		System.out.println("Comparing "+atomName+" with "+o.atomName);
		return atomName.compareTo(o.atomName);
	}
	
}