
public class SwapTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		IntegerPair ip = new IntegerPair(10,20);
		ip.print();
		ip.swap();
		ip.print();
	}

}

class IntegerPair
{
	int x;
	int y;
	public IntegerPair(int x, int y) {
		System.out.println("Interger pair(int,int)");
		this.x = x;
		this.y = y;
	}
	
	public void print()
	{
		System.out.println("x :"+x);
		System.out.println("y :"+y);
	}
	
	public void swap()
	{
		System.out.println("swapping....");
		int temp = x;	x = y;	y = temp;
		System.out.println("swapped....");
	}
}