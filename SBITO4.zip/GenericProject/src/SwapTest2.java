

public class SwapTest2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AnyPair<Integer> ip = new AnyPair<Integer>(10,20);
		ip.print();
		ip.swap();
		ip.print();
		System.out.println("----------------");
		AnyPair<Float> fl = new AnyPair<Float>(10.45f,20.25f);
		fl.print();
		fl.swap();
		fl.print();
		System.out.println("----------------");
		AnyPair<String> sg = new AnyPair<String>("God is Omnipresent","God is everywhere");
		sg.print();
		sg.swap();
		sg.print();
		System.out.println("----------------");
		
		Song s1 = new Song("I want it that way","Millenium","Backstreet Boys",2004);
		Song s2 = new Song("My Heart Will Go On","Titanic","Celine Dior",1995);

		AnyPair<Song> sp = new AnyPair<Song>(s1, s2);
		sp.print();
		sp.swap();
		sp.print();
	}

}

class AnyPair <T>
{
	T x;
	T y;
	public AnyPair(T x, T y) {
		System.out.println("Anypair(T,T)"+x.getClass());
		this.x = x;
		this.y = y;
	}
	
	public void print()
	{
		System.out.println("x :"+x);
		System.out.println("y :"+y);
	}
	
	public void swap()
	{
		System.out.println("swapping....");
		T temp = x;	x = y;	y = temp;
		System.out.println("swapped....");
	}
}

class Song {
	String title;
	String album;
	String artist;
	int year;
	
	
	public Song(String title, String album, String artist, int year) {
		super();
		this.title = title;
		this.album = album;
		this.artist = artist;
		this.year = year;
	}
	
	@Override
	public String toString() {
		return "Song [title=" + title + ", album=" + album + ", artist=" + artist + ", year=" + year + "]";
	}
	
	
}