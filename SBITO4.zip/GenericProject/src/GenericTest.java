import java.util.ArrayList;
import java.util.Iterator;

public class GenericTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		Egg eggArray[] = new Egg[12];
//		
//		eggArray[0] = new Egg("hen","white",7.50f,52.50f);
//		eggArray[1] = new Egg("hen","white",7.50f,52.50f);
//		eggArray[2] = new Egg("hen","white",7.50f,52.50f);
//		eggArray[3] = new Egg("hen","white",7.50f,52.50f);
//		eggArray[4] = new Egg("hen","white",7.50f,52.50f);
//		eggArray[5] = new Egg("hen","white",7.50f,52.50f);
//		eggArray[6] = new Egg("hen","white",7.50f,52.50f);
//		eggArray[7] = new Egg("hen","white",7.50f,52.50f);
//		eggArray[8] = new Egg("hen","white",7.50f,52.50f);
//		eggArray[9] = new Egg("hen","white",7.50f,52.50f);
//		eggArray[10] = new Egg("hen","white",7.50f,52.50f);
//		eggArray[11] = new Egg("hen","white",7.50f,52.50f);
//		eggArray[12] = new Egg("hen","white",7.50f,52.50f);
//		
//		for(int i=0; i<eggArray.length;i++) 
//		{
//			//eggArray[i] = new Egg("hen","white",7.50f,52.50f);
//			System.out.println(eggArray[i]);
//		}
		
		Egg egg1 = new Egg("Hen","White",7.00f,50.0f);
		Egg egg2 = new Egg("Hen","White",7.00f,55.0f);
		Egg egg3 = new Egg("Hen","White",7.00f,52.0f);
		Egg egg4 = new Egg("Hen","White",7.00f,51.0f);
		Egg egg5 = new Egg("Hen","White",7.00f,50.0f);
		Egg egg6 = new Egg("Hen","White",7.00f,55.0f);
		
		ArrayList<Egg> eggContainer = new ArrayList<Egg>();
		System.out.println("Egg container is created..");
		System.out.println("Adding egg1 ");
		eggContainer.add(egg1);
		
		System.out.println("Adding egg2 ");
		eggContainer.add(egg2);
		
		System.out.println("Adding egg3 ");
		eggContainer.add(egg3);
		
		System.out.println("Adding egg4 ");
		eggContainer.add(egg4);
		
		System.out.println("Adding egg5 ");
		eggContainer.add(egg5);
		
		System.out.println("Adding egg6 ");
		eggContainer.add(egg6);
		
		System.out.println("----iterating----");
		
		Iterator<Egg> eggIter = eggContainer.iterator();
		while(eggIter.hasNext()) {
			Egg theEgg = eggIter.next();
			System.out.println("The Egg : "+theEgg);
		
	}

}
class Egg
{
	String type;
	String color;
	float cost;
	float weight;
	public Egg(String type, String color, float cost, float weight) {
		super();
		this.type = type;
		this.color = color;
		this.cost = cost;
		this.weight = weight;
	}
	@Override
	public String toString() {
		return "Egg [type=" + type + ", color=" + color + ", cost=" + cost + ", weight=" + weight + "]";
	}
	
}
}