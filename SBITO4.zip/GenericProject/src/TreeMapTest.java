import java.util.TreeMap;

public class TreeMapTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Country c1 = new Country("India", "N.Delhi","Narendra Modi","136.64crores","rupee");
		Country c2 = new Country("Pakistan", "Islamabad", "Mr. Sharif", "21.66 Crores", "Pakistani Rupee");
		Country c3 = new Country("China", "Beijing", "Mr. Xi Jinping", "139.77 Crores", "Yuan");
		Country c4 = new Country("England", "London", "Mr. Boriss Johnson", "6.66 Crores", "Pound Sterling");
		Country c5 = new Country("America", "Washington DC", "Mr. Joe Biden", "32.82 Crores", "USD");
		
		TreeMap<String, Country> treemap = new TreeMap<String, Country>();
		System.out.println("Map is ready...");
		
		System.out.println("adding 1st country...");
		treemap.put("IND", c1);
		
		System.out.println("adding 2nd country...");
		treemap.put("IND", c2);
		
		System.out.println("adding 3rd country...");
		treemap.put("IND", c3);
		
		System.out.println("adding 4th country...");
		treemap.put("IND", c4);
		
		System.out.println("adding 5th country...");
		treemap.put("IND", c5);
		
	}

}
class Country
{
	String name,capital,primeMinister,population,currency;

	public Country(String name, String capital, String primeMinister, String population, String currency) {
		super();
		this.name = name;
		this.capital = capital;
		this.primeMinister = primeMinister;
		this.population = population;
		this.currency = currency;
	}

	@Override
	public String toString() {
		return "Country [name=" + name + ", capital=" + capital + ", primeMinister=" + primeMinister + ", population="
				+ population + ", currency=" + currency + "]";
	}
	
	
}