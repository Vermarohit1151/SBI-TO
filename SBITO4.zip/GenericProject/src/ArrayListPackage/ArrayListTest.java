package ArrayListPackage;
import java.time.LocalDate;
import java.util.ArrayList;

public class ArrayListTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Log1 l1 = new Log1("srinidhi", "dialed", LocalDate.now());
		Log1 l2 = new Log1("rajesh", "missed", LocalDate.now());
		Log1 l3 = new Log1("lokesh", "incoming", LocalDate.now());
		ArrayList<Log1> logData = new ArrayList<Log1>();
		
	
		System.out.println("Displaying the call Log data....");
		logData.add(new Log1("padma", "missed", LocalDate.now()));
		logData.add(l1);
		logData.add(new Log1("anil", "dialed", LocalDate.now()));
		logData.add(l2);
		logData.add(new Log1("harika", "incoming", LocalDate.now()));
		logData.add(l3);
		logData.add(new Log1("Jayendra", "missed", LocalDate.now()));
			
		for(int i=1; i<logData.size();i++)
		{
			System.out.println(+i+" :"+logData.get(i));
		}
		
		System.out.println("adding 7th log....");
		logData.add(new Log1("ramu", "outgoing", LocalDate.now()));
		
		System.out.println("7 :"+logData.get(7));
		
	}

}
