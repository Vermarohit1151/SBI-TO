package ArrayListPackage;

import java.time.LocalDate;

class Log1
{
	String callerName;
	String callType;
	LocalDate callDate;
	
	public Log1(String callerName, String callType, LocalDate callDate) {
		super();
		this.callerName = callerName;
		this.callType = callType;
		this.callDate = callDate;
	}

	@Override
	public String toString() {
		return "Log [callerName=" + callerName + ", callType=" + callType + ", callDate=" + callDate + "]";
	}
	
	
	
}