package LinkedListPackage;

class Contacts
{
	String conName;
	long mobileNo;
	String email;
	public Contacts(String conName, long mobileNo, String email) {
		super();
		this.conName = conName;
		this.mobileNo = mobileNo;
		this.email = email;
	}
	@Override
	public String toString() {
		return "Contacts [conName=" + conName + ", mobileNo=" + mobileNo + ", email=" + email + "]";
	}
	
	
}