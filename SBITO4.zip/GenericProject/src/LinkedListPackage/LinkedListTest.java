package LinkedListPackage;
import java.util.LinkedList;

public class LinkedListTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedList<Contacts> conData = new LinkedList<Contacts>();
		
		Contacts cd1 = new Contacts("Manish", 7895687945l, "manish45@gmail.com");
		Contacts cd2 = new Contacts("Manish", 7895687945l, "manish45@gmail.com");
		Contacts cd3 = new Contacts("Manish", 7895687945l, "manish45@gmail.com");
		Contacts cd4 = new Contacts("Manish", 7895687945l, "manish45@gmail.com");
		
		conData.add(cd1);
		conData.add(new Contacts("Sirish", 7568954625l,"siridh678@yahoo.com"));
		
		conData.add(cd2);
		conData.add(new Contacts("Nimya", 7568954625l,"nimya.p@yahoo.com"));
		
		conData.add(cd3);
		conData.add(new Contacts("Bheemesh", 7568954625l,"bheemesh.r@gmail.com"));
		
		conData.add(cd4);
		conData.add(new Contacts("Rahul", 7568954625l,"rahuly@yahoo.com"));
		
		for(int i=1; i<conData.size();i++)
		{
			System.out.println(i+" :"+conData.get(i));
		}
		
	}

}

