package myExceptions;

public class EmptyTableException extends RuntimeException {

	public EmptyTableException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
