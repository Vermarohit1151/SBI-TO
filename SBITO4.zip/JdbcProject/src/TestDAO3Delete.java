import daoPackage.Employee;
import daoPackage.EmployeeDaoImpl;

public class TestDAO3Delete {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EmployeeDaoImpl empDAO = new EmployeeDaoImpl();
//		Employee empObj = new Employee();
//		empObj.setEmpNo(1010);
		
		empDAO.deleteEmployee(1010);
		
	}

}
