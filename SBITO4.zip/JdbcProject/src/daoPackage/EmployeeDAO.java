package daoPackage;

import java.util.List;

import myExceptions.EmployeeAlreadyExistsException;
import myExceptions.EmployeeNotFoundException;
import myExceptions.EmptyTableException;

public interface EmployeeDAO {
	//CRUD
	void createEmployee(Employee empObj) throws EmployeeAlreadyExistsException;
	Employee readEmployee(int empNo)throws EmployeeNotFoundException;
	List<Employee> readAllEmployees() throws EmptyTableException;
	void updateEmployee(Employee empObj);
	void deleteEmployee(int empNo);
	
	
}
