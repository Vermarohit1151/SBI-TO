package daoPackage;

import java.sql.Date;

public class Employee {
	private int empNo;
	private String empName;
	private String empJob;
	private int empManagerCode;
	private Date empHireDate;
	private double basicSal;
	private double empComm;
	private int empDeptNo;
	public int getEmpNo() {
		return empNo;
	}
	public void setEmpNo(int empNo) {
		this.empNo = empNo;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getEmpJob() {
		return empJob;
	}
	public void setEmpJob(String empJob) {
		this.empJob = empJob;
	}
	public int getEmpManagerCode() {
		return empManagerCode;
	}
	public void setEmpManagerCode(int empManagerCode) {
		this.empManagerCode = empManagerCode;
	}
	public Date getEmpHireDate() {
		return empHireDate;
	}
	public void setEmpHireDate(Date empHireDate) {
		this.empHireDate = empHireDate;
	}
	public double getBasicSal() {
		return basicSal;
	}
	public void setBasicSal(double basicSal) {
		this.basicSal = basicSal;
	}
	public double getEmpComm() {
		return empComm;
	}
	public void setEmpComm(double empComm) {
		this.empComm = empComm;
	}
	public int getEmpDeptNo() {
		return empDeptNo;
	}
	public void setEmpDeptNo(int empDeptNo) {
		this.empDeptNo = empDeptNo;
	}
	
	
}
