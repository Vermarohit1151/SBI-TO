import java.sql.Date;

import daoPackage.Employee;
import daoPackage.EmployeeDaoImpl;

public class TestDAO3Insert {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EmployeeDaoImpl empDAO = new EmployeeDaoImpl();
		
		Employee empObj = new Employee();
		empObj.setEmpNo(1010);
		empObj.setEmpName("Sri");
		empObj.setEmpJob("Manager");
		empObj.setEmpManagerCode(7566);
		empObj.setEmpHireDate(Date.valueOf("2021-12-12"));
		empObj.setBasicSal(4562.25);
		empObj.setEmpComm(456);
		empObj.setEmpDeptNo(20);
			
		empDAO.createEmployee(empObj);

	}

}
