import java.util.List;

import daoPackage.Employee;
import daoPackage.EmployeeDaoImpl;

public class TestDAO2 {
	public static void main(String[] args) {
		EmployeeDaoImpl empDAO = new EmployeeDaoImpl();
		
		List<Employee> empList = empDAO.readAllEmployees();
			
			for (Employee empObj : empList) {
		
				System.out.println("EMPNO   : "+empObj.getEmpNo());				
				System.out.println("ENAME   : "+empObj.getEmpName());				
				System.out.println("JOB     : "+empObj.getEmpJob());
				System.out.println("DOJ     : "+empObj.getEmpHireDate());
				
				System.out.println("MANAGER : "+empObj.getEmpManagerCode());				
				System.out.println("SALARY  : "+empObj.getBasicSal());				
				System.out.println("COMM    : "+empObj.getEmpComm());
				System.out.println("DEPTNO  : "+empObj.getEmpDeptNo());
				System.out.println("----------------------------");
			}
		//empDAO.closeDBResources();
	}
}