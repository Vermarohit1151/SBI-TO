
public class ChessTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Chess c1 = new Chess();
		GraphicalChess gc1 = new GraphicalChess();
		Chess c2 = new GraphicalChess();
		//sysout
		c1.moveBishop();
		c1.moveQueen();
		
		c2.moveBishop();
		//c2.moveMyBishop();
		
		gc1.moveMyBishop();
		gc1.moveBishop();
	}

}

class Chess
{
	final int tot_sqrs = 64;
	final void moveBishop()
	{
		System.out.println("cross bidirection...of bishop....");
	}
	
	final void moveQueen()
	{
		System.out.println("horizontal/vertical/cross...bi-directional...");
	}
}

class GraphicalChess extends Chess
{

	void moveMyBishop()
	{
		super.moveBishop();
		System.out.println("Logic is done for Graphical chess");
	}
}