
public class CircleTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		Circle c1 = new Circle(25.56);
			
		System.out.println("Area of circle :"+c1.calArea()+" sq.m.");
		System.out.println("value of PI :"+c1.pi);
		
	}

}

class Circle
{
	final double pi = 3.14;
	double radius;
	
	public Circle(double radius) {
		super();
		this.radius = radius;
	}
	
	double calArea()
	{
		System.out.println("value of PI :"+pi);
		System.out.println("------------------");
		double area = pi * radius * radius;
		return area;
	}
}