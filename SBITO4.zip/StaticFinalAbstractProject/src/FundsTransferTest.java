
import java.time.LocalDate;

public class FundsTransferTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("Begin of main.......");

		
		
		System.out.println("End of main.......");
	}
	
}

class BankAccount
{
	int accNo;
	String accName;
	double accBalance;
	
	public BankAccount(int accNo, String accName, double accBalance) {
		super();
		this.accNo = accNo;
		this.accName = accName;
		this.accBalance = accBalance;
	}
	
}

interface Withdrawing
{
	void Withdraw(double amt);
	double getBalance();
	
}

interface Depositing
{
	void deposit(double amt);
	double getBalance();
	
}
class CurrentAccount extends BankAccount implements Withdrawing, Depositing
{

	public CurrentAccount(int accNo, String accName, double accBalance) {
		super(accNo, accName, accBalance);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void deposit(double amt) {
		System.out.println("Depositing in Curent account..."+amt);
		accBalance = accBalance + amt;
	}

	@Override
	public void Withdraw(double amt) {
		System.out.println("Withdrawing in Curent account..."+amt);
		accBalance = accBalance - amt;
	}

	@Override
	public double getBalance() {
		// TODO Auto-generated method stub
		return 0;
	}
	
}

class SavingsAccount extends BankAccount implements Depositing
{
	
public SavingsAccount(int accNo, String accName, double accBalance) {
		super(accNo, accName, accBalance);
		// TODO Auto-generated constructor stub
	}


	@Override
	public String toString() {
		return "BankAccount [accNo=" + accNo + ", accName=" + accName + ", accBalance=" + accBalance + "]";
	}



	public void withdrawl(double amtToWithdraw)
	{
		if(amtToWithdraw > accBalance)
		{
			throw new RuntimeException("Insufficent funds.....");
		}
		System.out.println(accName+" is withdrawing "+amtToWithdraw+" Rupees...");
		accBalance = accBalance-amtToWithdraw;
	}
	
	public void deposit(double amt)
	{
		System.out.println("Depositing in Savings account..."+amt);
		accBalance = accBalance + amt;
	}



	@Override
	public double getBalance() {
		// TODO Auto-generated method stub
		return 0;
	}
}
