
public class AbstractTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		GeometricalShape gs = new Circle1(25.8);
		gs.draw();
		gs.calcArea();
		gs.calcPerimeter();
		
		gs = new Square1(45);
		gs.draw();
		gs.calcArea();
		gs.calcPerimeter();
		
		gs = new Rectangle(45,40);
		gs.draw();
		gs.calcArea();
		gs.calcPerimeter();
	}

}

abstract class GeometricalShape
{
	final double pi=3.14;
	abstract void draw();
	abstract void calcArea();
	abstract void calcPerimeter();
	
}

class Circle1 extends GeometricalShape
{
	double radius;
	
	
	public Circle1(double radius) {
		super();
		this.radius = radius;
	}

	@Override
	void draw() {
		// TODO Auto-generated method stub
		System.out.println("Circle is drawn.......");
	}

	@Override
	void calcArea() {
		// TODO Auto-generated method stub
		double area = radius * radius;
		System.out.println("Area of Circle is :"+area);
		System.out.println("----------------------------");
	}

	@Override
	void calcPerimeter() {
		// TODO Auto-generated method stub
		double perimeter = 2*pi*radius;
		System.out.println("Perimeter of circle is :"+perimeter);
		System.out.println("----------------------------");
	}
	
}

class Square1 extends GeometricalShape
{
	double side;
	
	public Square1(double side) {
		super();
		this.side = side;
	}

	@Override
	void draw() {
		// TODO Auto-generated method stub
		System.out.println("Square is drawn.......");
	}

	@Override
	void calcArea() {
		// TODO Auto-generated method stub
		double area = side * side;
		System.out.println("Area of Square is :"+area);
		System.out.println("----------------------------");
	}

	@Override
	void calcPerimeter() {
		// TODO Auto-generated method stub
		double perimeter = 4 * side;
		System.out.println("Perimeter of square is :"+perimeter);
		System.out.println("----------------------------");
	}
	
}


class Rectangle extends Square1
{
	double side2;

	public Rectangle(double side, double side2) {
		super(side);
		this.side2 = side2;
	}
	
	@Override
	void draw() {
		// TODO Auto-generated method stub
		System.out.println("Rectangle is drawn.......");
	}

	@Override
	void calcArea() {
		// TODO Auto-generated method stub
		double area = side * side2;
		System.out.println("Area of Rectangle is :"+area);
		System.out.println("----------------------------");
	}

	@Override
	void calcPerimeter() {
		// TODO Auto-generated method stub
		double perimeter = 2 * (side+side2);
		System.out.println("Perimeter of Rectangle is :"+perimeter);
		System.out.println("----------------------------");
	}
}