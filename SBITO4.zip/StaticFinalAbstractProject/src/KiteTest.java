
public class KiteTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Kite k1 = new Kite("red", 10, "rushi");
		System.out.println("Kite1: "+k1);
		Kite k2 = new Kite("orange", 30, "srinidhi");
		System.out.println("Kite1: "+k2);
		Kite k3 = new Kite("green", 50, "anil");
		System.out.println("Kite1: "+k3);
		
		Kite.printKite();
		k1.kiteFight(k2);
		k2.kiteFight(k3);
	}

}

class Kite
{
	private static int kiteCount;
	
	private String kiteColor;
	private int kiteLength;
	private String kiteOwner;
	private boolean flyingStatus;
	
	public Kite(String kiteColor, int kiteLength, String kiteOwner) {
		super();
		this.kiteColor = kiteColor;
		this.kiteLength = kiteLength;
		this.kiteOwner = kiteOwner;
		flyingStatus = true;
		++kiteCount;
		}
	
	void kiteFight(Kite x) {
		System.out.println(kiteColor+" color kite initiated kite fight with "+x.kiteColor+" color kite");
		
		for(int i=1;i<=20;i++) {
			double v = Math.random()%10; // 0 to 1
			System.out.println(i+" v "+v);
			if(v > 0.98) {
				flyingStatus=false;
				kiteCount--;
				System.out.println(kiteColor+" kite is down...");
				break;
			}
			else if(v < 0.01) {
				x.flyingStatus=false;
				kiteCount--;
				System.out.println(x.kiteColor+" kite is down...");
				break;
			} 
			else if ( v >= 0.60 && v<=0.70) {
				flyingStatus=false;
				x.flyingStatus=false;
				System.out.println("Both kites are down...");
				kiteCount= kiteCount-2;
				break;
			}
		}
	}
	
	@Override
	public String toString() {
		return "Kite [kiteColor=" + kiteColor + ", kiteLength=" + kiteLength + ", kiteOwner=" + kiteOwner
				+ ", flyingStatus=" + flyingStatus + "]";
	}





	public static void printKite()
	{
		System.out.println("No. of kites in the sky "+kiteCount);
	}
	
}