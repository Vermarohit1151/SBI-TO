
public class InstrumentTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}

abstract class MusicalInstrument
{
	abstract void play();
}

abstract class stringBasedMusicalInstrument extends MusicalInstrument
{
	abstract void tuneStrings();
}

class Guitar extends MusicalInstrument
{

	@Override
	void play() {
		// TODO Auto-generated method stub
		
	}
	
}